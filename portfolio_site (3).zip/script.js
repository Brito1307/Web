function scrollToWork() {
  document.getElementById("work").scrollIntoView({ behavior: "smooth" });
}
